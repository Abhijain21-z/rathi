
'use client';

export default function AchievementsSection() {
  const achievements = [
    {
      title: "ISO 9001:2015 Certified",
      description: "Quality management system certification for healthcare services",
      icon: "ri-award-line"
    },
    {
      title: "Best Hospital Award 2023",
      description: "Recognized as the best healthcare provider in Betul district",
      icon: "ri-trophy-line"
    },
    {
      title: "15+ Years of Excellence",
      description: "Over a decade of trusted healthcare services in the region",
      icon: "ri-time-line"
    },
    {
      title: "NABH Accredited",
      description: "National Accreditation Board for Hospitals certification",
      icon: "ri-shield-check-line"
    }
  ];

  const stats = [
    { number: "50,000+", label: "Patients Treated" },
    { number: "15+", label: "Years of Service" },
    { number: "50+", label: "Medical Specialists" },
    { number: "24/7", label: "Emergency Care" }
  ];

  return (
    <section className="py-20 bg-blue-600">
      <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8">
        <div className="text-center mb-16">
          <h2 className="text-4xl font-bold text-white mb-4">Our Achievements</h2>
          <p className="text-lg text-blue-100 max-w-3xl mx-auto">
            Recognition and certifications that reflect our commitment to excellence 
            in healthcare delivery and patient satisfaction.
          </p>
        </div>
        
        <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-4 gap-8 mb-16">
          {achievements.map((achievement, index) => (
            <div key={index} className="text-center">
              <div className="w-16 h-16 flex items-center justify-center bg-white/20 text-white rounded-full mx-auto mb-4">
                <i className={`${achievement.icon} text-2xl`}></i>
              </div>
              <h3 className="text-xl font-semibold text-white mb-2">{achievement.title}</h3>
              <p className="text-blue-100 text-sm leading-relaxed">{achievement.description}</p>
            </div>
          ))}
        </div>
        
        <div className="border-t border-blue-500 pt-16">
          <div className="grid grid-cols-2 md:grid-cols-4 gap-8 text-center">
            {stats.map((stat, index) => (
              <div key={index}>
                <div className="text-4xl font-bold text-white mb-2">{stat.number}</div>
                <div className="text-blue-100">{stat.label}</div>
              </div>
            ))}
          </div>
        </div>
      </div>
    </section>
  );
}
