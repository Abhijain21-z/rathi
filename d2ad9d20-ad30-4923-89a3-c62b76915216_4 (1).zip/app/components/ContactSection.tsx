
'use client';

export default function ContactSection() {
  return (
    <section id="contact" className="py-20 bg-white">
      <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8">
        <div className="text-center mb-16">
          <h2 className="text-4xl font-bold text-gray-800 mb-4">Contact Us</h2>
          <p className="text-lg text-gray-600 max-w-3xl mx-auto">
            Get in touch with us for any medical emergency or to schedule an appointment. 
            We're here to provide you with the best healthcare services.
          </p>
        </div>
        
        <div className="grid grid-cols-1 lg:grid-cols-2 gap-12">
          <div>
            <div className="space-y-8">
              <div className="flex items-start space-x-4">
                <div className="w-12 h-12 flex items-center justify-center bg-blue-600 text-white rounded-lg flex-shrink-0">
                  <i className="ri-map-pin-line text-xl"></i>
                </div>
                <div>
                  <h3 className="text-xl font-semibold text-gray-800 mb-2">Address</h3>
                  <p className="text-gray-600 leading-relaxed">
                    Goverdhan Rathi Hospital<br />
                    Betul Eklaira Road<br />
                    Kashi Talab, Betul<br />
                    Madhya Pradesh 460001
                  </p>
                </div>
              </div>
              
              <div className="flex items-start space-x-4">
                <div className="w-12 h-12 flex items-center justify-center bg-blue-600 text-white rounded-lg flex-shrink-0">
                  <i className="ri-phone-line text-xl"></i>
                </div>
                <div>
                  <h3 className="text-xl font-semibold text-gray-800 mb-2">Phone</h3>
                  <p className="text-gray-600">
                    <a href="tel:07141230888" className="hover:text-blue-600 transition-colors cursor-pointer">
                      07141 230 888
                    </a>
                  </p>
                  <p className="text-sm text-gray-500 mt-1">24/7 Emergency Helpline</p>
                </div>
              </div>
              
              <div className="flex items-start space-x-4">
                <div className="w-12 h-12 flex items-center justify-center bg-blue-600 text-white rounded-lg flex-shrink-0">
                  <i className="ri-time-line text-xl"></i>
                </div>
                <div>
                  <h3 className="text-xl font-semibold text-gray-800 mb-2">Working Hours</h3>
                  <div className="text-gray-600 space-y-1">
                    <p>OPD: 9:00 AM - 8:00 PM</p>
                    <p>Emergency: 24/7</p>
                    <p>ICU: 24/7</p>
                  </div>
                </div>
              </div>
              
              <div className="flex items-start space-x-4">
                <div className="w-12 h-12 flex items-center justify-center bg-blue-600 text-white rounded-lg flex-shrink-0">
                  <i className="ri-mail-line text-xl"></i>
                </div>
                <div>
                  <h3 className="text-xl font-semibold text-gray-800 mb-2">Email</h3>
                  <p className="text-gray-600">
                    <a href="mailto:info@grhospital.com" className="hover:text-blue-600 transition-colors cursor-pointer">
                      info@grhospital.com
                    </a>
                  </p>
                </div>
              </div>
            </div>
          </div>
          
          <div>
            <div className="bg-gray-50 rounded-lg overflow-hidden shadow-lg">
              <iframe
                src="https://www.google.com/maps/embed?pb=!1m18!1m12!1m3!1d3662.123456789!2d77.89472198!3d21.90434456!2m3!1f0!2f0!3f0!3m2!1i1024!2i768!4f13.1!3m3!1m2!1s0x0%3A0x0!2zMjHCsDU0JzE1LjYiTiA3N8KwNTMnNDEuMCJF!5e0!3m2!1sen!2sin!4v1620000000000!5m2!1sen!2sin"
                width="100%"
                height="400"
                style={{ border: 0 }}
                allowFullScreen
                loading="lazy"
                referrerPolicy="no-referrer-when-downgrade"
                title="Goverdhan Rathi Hospital Location"
              ></iframe>
            </div>
          </div>
        </div>
      </div>
    </section>
  );
}
