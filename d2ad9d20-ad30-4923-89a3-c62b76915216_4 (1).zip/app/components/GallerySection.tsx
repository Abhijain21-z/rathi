
'use client';

import { useState } from 'react';

export default function GallerySection() {
  const [currentSlide, setCurrentSlide] = useState(0);
  
  const images = [
    {
      url: "https://readdy.ai/api/search-image?query=Hospital%20reception%20area%20with%20modern%20furniture%2C%20clean%20white%20and%20blue%20interior%20design%2C%20medical%20facility%20lobby%20with%20comfortable%20seating%2C%20professional%20healthcare%20environment%2C%20bright%20hospital%20entrance%20with%20information%20desk&width=800&height=500&seq=gallery1&orientation=landscape",
      title: "Reception Area"
    },
    {
      url: "https://readdy.ai/api/search-image?query=Modern%20hospital%20patient%20room%20with%20medical%20bed%2C%20clean%20white%20interior%2C%20medical%20equipment%2C%20comfortable%20patient%20accommodation%2C%20healthcare%20facility%20bedroom%20with%20blue%20accents%2C%20sterile%20hospital%20room%20design&width=800&height=500&seq=gallery2&orientation=landscape",
      title: "Patient Room"
    },
    {
      url: "https://readdy.ai/api/search-image?query=Hospital%20operation%20theater%20with%20surgical%20equipment%2C%20modern%20operating%20room%2C%20sterile%20surgical%20environment%2C%20medical%20procedure%20room%20with%20advanced%20technology%2C%20blue%20and%20white%20surgical%20suite%20design&width=800&height=500&seq=gallery3&orientation=landscape",
      title: "Operation Theater"
    },
    {
      url: "https://readdy.ai/api/search-image?query=Hospital%20laboratory%20with%20medical%20testing%20equipment%2C%20pathology%20lab%20interior%2C%20diagnostic%20facility%2C%20medical%20research%20environment%2C%20clean%20laboratory%20setting%20with%20modern%20instruments%2C%20healthcare%20testing%20facility&width=800&height=500&seq=gallery4&orientation=landscape",
      title: "Laboratory"
    }
  ];

  const nextSlide = () => {
    setCurrentSlide((prev) => (prev + 1) % images.length);
  };

  const prevSlide = () => {
    setCurrentSlide((prev) => (prev - 1 + images.length) % images.length);
  };

  return (
    <section className="py-20 bg-gray-50">
      <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8">
        <div className="text-center mb-16">
          <h2 className="text-4xl font-bold text-gray-800 mb-4">Hospital Gallery</h2>
          <p className="text-lg text-gray-600 max-w-3xl mx-auto">
            Take a virtual tour of our modern facilities and see our commitment 
            to providing a clean, comfortable, and professional healthcare environment.
          </p>
        </div>
        
        <div className="relative max-w-4xl mx-auto">
          <div className="relative h-96 rounded-lg overflow-hidden shadow-xl">
            <img 
              src={images[currentSlide].url}
              alt={images[currentSlide].title}
              className="w-full h-full object-cover object-top transition-opacity duration-500"
            />
            <div className="absolute bottom-0 left-0 right-0 bg-gradient-to-t from-black/70 to-transparent p-6">
              <h3 className="text-white text-xl font-semibold">{images[currentSlide].title}</h3>
            </div>
          </div>
          
          <button 
            onClick={prevSlide}
            className="absolute left-4 top-1/2 transform -translate-y-1/2 bg-white/80 hover:bg-white text-gray-800 p-3 rounded-full shadow-lg transition-all duration-200 cursor-pointer"
          >
            <div className="w-6 h-6 flex items-center justify-center">
              <i className="ri-arrow-left-line text-xl"></i>
            </div>
          </button>
          
          <button 
            onClick={nextSlide}
            className="absolute right-4 top-1/2 transform -translate-y-1/2 bg-white/80 hover:bg-white text-gray-800 p-3 rounded-full shadow-lg transition-all duration-200 cursor-pointer"
          >
            <div className="w-6 h-6 flex items-center justify-center">
              <i className="ri-arrow-right-line text-xl"></i>
            </div>
          </button>
          
          <div className="flex justify-center mt-6 space-x-2">
            {images.map((_, index) => (
              <button
                key={index}
                onClick={() => setCurrentSlide(index)}
                className={`w-3 h-3 rounded-full transition-colors cursor-pointer ${
                  index === currentSlide ? 'bg-blue-600' : 'bg-gray-300'
                }`}
              />
            ))}
          </div>
        </div>
      </div>
    </section>
  );
}
