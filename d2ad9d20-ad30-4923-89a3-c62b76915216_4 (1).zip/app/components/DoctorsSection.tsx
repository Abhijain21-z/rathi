
'use client';

export default function DoctorsSection() {
  const doctors = [
    {
      name: "Dr. Nitin Rathi",
      specialization: "Brachial Plexus Surgeon",
      experience: "20 Years",
      education: "MBBS, MS Orthopedics, Fellowship in Brachial Plexus Surgery",
      image: "https://encrypted-tbn0.gstatic.com/images?q=tbn:ANd9GcTL_WValSgKoxOwwj4OiFnjiKOD8KXcKbtUomqqfb9Kea_LOPvp6BJDghmX1qDfMDFq8Jo&usqp=CAU"
    },
    {
      name: "Dr. Dipti Rathi",
      specialization: "Gynaecologist",
      experience: "15 Years",
      education: "MBBS, MS Gynecology & Obstetrics",
      image: "https://readdy.ai/api/search-image?query=Professional%20Indian%20female%20doctor%20in%20white%20coat%20with%20stethoscope%2C%20experienced%20gynaecologist%2C%20medical%20practitioner%20portrait%2C%20clean%20medical%20background%2C%20confident%20female%20gynecology%20doctor%20with%20medical%20equipment%2C%20hospital%20setting%20with%20blue%20and%20white%20theme&width=300&height=400&seq=doctorDipti&orientation=portrait"
    },
    {
      name: "Dr. Amit Patel",
      specialization: "Orthopedic Surgeon",
      experience: "18 Years",
      education: "MBBS, MS Orthopedics",
      image: "https://readdy.ai/api/search-image?query=Professional%20Indian%20male%20surgeon%20in%20white%20coat%20with%20medical%20equipment%2C%20experienced%20healthcare%20professional%2C%20surgical%20specialist%20portrait%2C%20clean%20medical%20background%2C%20confident%20orthopedic%20doctor%2C%20hospital%20setting%20with%20blue%20and%20white%20theme&width=300&height=400&seq=doctor3&orientation=portrait"
    }
  ];

  return (
    <section id="doctors" className="py-20 bg-gray-50">
      <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8">
        <div className="text-center mb-16">
          <h2 className="text-4xl font-bold text-gray-800 mb-4">Our Expert Doctors</h2>
          <p className="text-lg text-gray-600 max-w-3xl mx-auto">
            Our team of experienced and qualified doctors are dedicated to providing 
            the best medical care with compassion and expertise.
          </p>
        </div>
        
        <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-8">
          {doctors.map((doctor, index) => (
            <div key={index} className="bg-white rounded-lg shadow-lg overflow-hidden hover:shadow-xl transition-shadow duration-300">
              <div className="aspect-w-3 aspect-h-4">
                <img 
                  src={doctor.image}
                  alt={doctor.name}
                  className="w-full h-80 object-cover object-top"
                />
              </div>
              <div className="p-6">
                <h3 className="text-xl font-semibold text-gray-800 mb-2">{doctor.name}</h3>
                <p className="text-blue-600 font-medium mb-2">{doctor.specialization}</p>
                <p className="text-gray-600 mb-1">Experience: {doctor.experience}</p>
                <p className="text-gray-600 mb-4">{doctor.education}</p>
                <button className="bg-blue-600 text-white px-4 py-2 rounded-md hover:bg-blue-700 transition-colors w-full whitespace-nowrap cursor-pointer">
                  Book Appointment
                </button>
              </div>
            </div>
          ))}
        </div>
      </div>
    </section>
  );
}
