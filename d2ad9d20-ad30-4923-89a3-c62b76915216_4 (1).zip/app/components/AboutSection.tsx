
'use client';

export default function AboutSection() {
  return (
    <section id="about" className="py-20 bg-white">
      <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8">
        <div className="grid grid-cols-1 lg:grid-cols-2 gap-12 items-center">
          <div>
            <h2 className="text-4xl font-bold text-gray-800 mb-6">About Our Hospital</h2>
            <p className="text-lg text-gray-600 mb-6 leading-relaxed">
              Goverdhan Rathi Hospital is a reputed healthcare institution in Betul, Madhya Pradesh, 
              dedicated to providing comprehensive medical services with state-of-the-art facilities 
              and compassionate care.
            </p>
            <p className="text-lg text-gray-600 mb-6 leading-relaxed">
              With years of experience in healthcare, we offer complete medical solutions ranging 
              from routine check-ups to complex surgical procedures. Our team of qualified doctors 
              and medical professionals ensures the highest standards of patient care.
            </p>
            <div className="grid grid-cols-2 gap-6">
              <div className="text-center">
                <div className="text-3xl font-bold text-blue-600">15+</div>
                <div className="text-gray-600">Years of Service</div>
              </div>
              <div className="text-center">
                <div className="text-3xl font-bold text-blue-600">50+</div>
                <div className="text-gray-600">Expert Doctors</div>
              </div>
              <div className="text-center">
                <div className="text-3xl font-bold text-blue-600">10000+</div>
                <div className="text-gray-600">Happy Patients</div>
              </div>
              <div className="text-center">
                <div className="text-3xl font-bold text-blue-600">24/7</div>
                <div className="text-gray-600">Emergency Care</div>
              </div>
            </div>
          </div>
          <div className="relative">
            <img 
              src="https://readdy.ai/api/search-image?query=Modern%20hospital%20interior%20with%20medical%20equipment%2C%20clean%20white%20corridors%20with%20medical%20staff%2C%20professional%20healthcare%20environment%2C%20hospital%20lobby%20with%20reception%20area%2C%20medical%20facility%20interior%20design%20with%20blue%20and%20white%20color%20scheme%2C%20bright%20and%20sterile%20hospital%20hallways&width=600&height=400&seq=about-hospital&orientation=landscape"
              alt="Hospital Interior"
              className="rounded-lg shadow-xl w-full h-96 object-cover object-top"
            />
          </div>
        </div>
      </div>
    </section>
  );
}
