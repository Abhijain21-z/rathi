
'use client';

export default function ServicesSection() {
  const services = [
    {
      title: "OPD Services",
      description: "Comprehensive outpatient department with specialist consultations",
      icon: "ri-hospital-line"
    },
    {
      title: "Emergency Care",
      description: "24/7 emergency medical services with immediate response",
      icon: "ri-alarm-warning-line"
    },
    {
      title: "ICU",
      description: "Advanced intensive care unit with modern life support systems",
      icon: "ri-heart-pulse-line"
    },
    {
      title: "Diagnostics",
      description: "Complete diagnostic services including lab tests and imaging",
      icon: "ri-microscope-line"
    },
    {
      title: "Surgery",
      description: "State-of-the-art surgical facilities with experienced surgeons",
      icon: "ri-surgical-mask-line"
    },
    {
      title: "Pharmacy",
      description: "In-house pharmacy with all essential medicines available",
      icon: "ri-capsule-line"
    },
    {
      title: "Ambulance",
      description: "24/7 ambulance service for emergency transportation",
      icon: "ri-truck-line"
    }
  ];

  return (
    <section id="services" className="py-20 bg-white">
      <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8">
        <div className="text-center mb-16">
          <h2 className="text-4xl font-bold text-gray-800 mb-4">Our Services</h2>
          <p className="text-lg text-gray-600 max-w-3xl mx-auto">
            We provide comprehensive healthcare services with modern facilities 
            and experienced medical professionals to ensure the best patient care.
          </p>
        </div>
        
        <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 xl:grid-cols-4 gap-6">
          {services.map((service, index) => (
            <div key={index} className="bg-gray-50 rounded-lg p-6 hover:shadow-lg transition-shadow duration-300 hover:bg-blue-50">
              <div className="w-12 h-12 flex items-center justify-center bg-blue-600 text-white rounded-lg mb-4">
                <i className={`${service.icon} text-xl`}></i>
              </div>
              <h3 className="text-xl font-semibold text-gray-800 mb-3">{service.title}</h3>
              <p className="text-gray-600 leading-relaxed">{service.description}</p>
            </div>
          ))}
        </div>
      </div>
    </section>
  );
}
