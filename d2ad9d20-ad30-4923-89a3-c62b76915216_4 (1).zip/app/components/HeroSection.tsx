
'use client';

export default function HeroSection() {
  return (
    <section id="home" className="relative h-screen flex items-center justify-center bg-gradient-to-r from-blue-50 to-white overflow-hidden">
      <div 
        className="absolute inset-0 z-0"
        style={{
          backgroundImage: `url('https://readdy.ai/api/search-image?query=Modern%20hospital%20building%20exterior%20with%20clean%20white%20and%20blue%20design%2C%20medical%20center%20with%20glass%20windows%2C%20healthcare%20facility%20architecture%2C%20professional%20medical%20building%20with%20clear%20blue%20sky%20background%2C%20minimalist%20hospital%20facade%20with%20modern%20design%20elements%2C%20bright%20and%20welcoming%20healthcare%20environment&width=1920&height=1080&seq=hero-hospital&orientation=landscape')`,
          backgroundSize: 'cover',
          backgroundPosition: 'center',
          backgroundRepeat: 'no-repeat'
        }}
      >
        <div className="absolute inset-0 bg-blue-900/40"></div>
      </div>
      
      <div className="relative z-10 text-center text-white max-w-4xl mx-auto px-4">
        <div className="max-w-4xl">
          <h1 className="text-5xl md:text-7xl font-bold text-white mb-4" style={{fontFamily: 'Arial, sans-serif', fontWeight: 'bold'}}>
            Goverdhan Rathi Hospital
          </h1>
          <p className="text-xl md:text-2xl text-white mb-6 leading-relaxed">
            Betul Eklaira Road, Kashi Talab, Betul, MP 460001
          </p>
          <p className="text-xl md:text-2xl text-white mb-8 leading-relaxed">
            Quality Care. Trusted Service.
          </p>
        </div>
        <div className="flex flex-col sm:flex-row gap-4 justify-center">
          <a 
            href="tel:07141230888" 
            className="bg-blue-600 hover:bg-blue-700 text-white px-8 py-4 rounded-full text-lg font-semibold transition-all duration-300 transform hover:scale-105 whitespace-nowrap cursor-pointer"
          >
            Call Now – 07141 230 888
          </a>
          <a 
            href="#appointment" 
            className="bg-white hover:bg-gray-100 text-blue-600 px-8 py-4 rounded-full text-lg font-semibold transition-all duration-300 transform hover:scale-105 whitespace-nowrap cursor-pointer"
          >
            Book Appointment
          </a>
        </div>
      </div>
    </section>
  );
}
