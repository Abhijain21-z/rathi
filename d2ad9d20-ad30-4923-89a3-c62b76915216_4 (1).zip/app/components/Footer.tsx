
'use client';

export default function Footer() {
  return (
    <footer className="bg-gray-800 text-white py-12">
      <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8">
        <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-4 gap-8">
          <div>
            <h3 className="text-2xl font-bold mb-4" style={{fontFamily: 'var(--font-pacifico)'}}>
              Goverdhan Rathi Hospital
            </h3>
            <p className="text-gray-300 mb-4 leading-relaxed">
              Providing quality healthcare services with compassion and excellence 
              in Betul, Madhya Pradesh.
            </p>
            <div className="flex space-x-4">
              <div className="w-8 h-8 flex items-center justify-center bg-blue-600 rounded-full hover:bg-blue-700 transition-colors cursor-pointer">
                <i className="ri-facebook-fill"></i>
              </div>
              <div className="w-8 h-8 flex items-center justify-center bg-blue-600 rounded-full hover:bg-blue-700 transition-colors cursor-pointer">
                <i className="ri-twitter-fill"></i>
              </div>
              <div className="w-8 h-8 flex items-center justify-center bg-blue-600 rounded-full hover:bg-blue-700 transition-colors cursor-pointer">
                <i className="ri-instagram-fill"></i>
              </div>
            </div>
          </div>
          
          <div>
            <h4 className="text-lg font-semibold mb-4">Quick Links</h4>
            <ul className="space-y-2">
              <li><a href="#home" className="text-gray-300 hover:text-white transition-colors cursor-pointer">Home</a></li>
              <li><a href="#about" className="text-gray-300 hover:text-white transition-colors cursor-pointer">About Us</a></li>
              <li><a href="#doctors" className="text-gray-300 hover:text-white transition-colors cursor-pointer">Our Doctors</a></li>
              <li><a href="#services" className="text-gray-300 hover:text-white transition-colors cursor-pointer">Services</a></li>
              <li><a href="#contact" className="text-gray-300 hover:text-white transition-colors cursor-pointer">Contact</a></li>
            </ul>
          </div>
          
          <div>
            <h4 className="text-lg font-semibold mb-4">Services</h4>
            <ul className="space-y-2">
              <li><span className="text-gray-300">Emergency Care</span></li>
              <li><span className="text-gray-300">ICU Services</span></li>
              <li><span className="text-gray-300">Surgery</span></li>
              <li><span className="text-gray-300">Diagnostics</span></li>
              <li><span className="text-gray-300">Pharmacy</span></li>
            </ul>
          </div>
          
          <div>
            <h4 className="text-lg font-semibold mb-4">Contact Info</h4>
            <div className="space-y-3">
              <div className="flex items-start space-x-3">
                <div className="w-5 h-5 flex items-center justify-center mt-1">
                  <i className="ri-map-pin-line text-blue-400"></i>
                </div>
                <span className="text-gray-300 text-sm">
                  Betul Eklaira Road, Kashi, Betul, MP 460001
                </span>
              </div>
              <div className="flex items-center space-x-3">
                <div className="w-5 h-5 flex items-center justify-center">
                  <i className="ri-phone-line text-blue-400"></i>
                </div>
                <a href="tel:07141230888" className="text-gray-300 hover:text-white transition-colors cursor-pointer">
                  07141 230 888
                </a>
              </div>
              <div className="flex items-center space-x-3">
                <div className="w-5 h-5 flex items-center justify-center">
                  <i className="ri-mail-line text-blue-400"></i>
                </div>
                <a href="mailto:info@grhospital.com" className="text-gray-300 hover:text-white transition-colors cursor-pointer">
                  info@grhospital.com
                </a>
              </div>
            </div>
          </div>
        </div>
        
        <div className="border-t border-gray-700 mt-8 pt-8 text-center">
          <p className="text-gray-300">
            &copy; 2024 Goverdhan Rathi Hospital. All rights reserved.
          </p>
        </div>
      </div>
    </footer>
  );
}
