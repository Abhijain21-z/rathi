
'use client';

import Link from 'next/link';

export default function Header() {
  return (
    <header className="bg-white shadow-md sticky top-0 z-50">
      <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8">
        <div className="flex justify-between items-center h-16">
          <div className="flex items-center">
            <h1 className="text-2xl font-bold text-blue-600" style={{fontFamily: 'var(--font-pacifico)'}}>
              Goverdhan Rathi Hospital
            </h1>
          </div>
          <nav className="hidden md:flex space-x-8">
            <a href="#home" className="text-gray-700 hover:text-blue-600 transition-colors cursor-pointer">Home</a>
            <a href="#about" className="text-gray-700 hover:text-blue-600 transition-colors cursor-pointer">About</a>
            <a href="#doctors" className="text-gray-700 hover:text-blue-600 transition-colors cursor-pointer">Doctors</a>
            <a href="#services" className="text-gray-700 hover:text-blue-600 transition-colors cursor-pointer">Services</a>
            <a href="#facility" className="text-gray-700 hover:text-blue-600 transition-colors cursor-pointer">Facility</a>
            <a href="#contact" className="text-gray-700 hover:text-blue-600 transition-colors cursor-pointer">Contact</a>
          </nav>
          <div className="flex items-center space-x-4">
            <a href="tel:07141230888" className="bg-blue-600 text-white px-4 py-2 rounded-md hover:bg-blue-700 transition-colors whitespace-nowrap cursor-pointer">
              Call Now
            </a>
          </div>
        </div>
      </div>
    </header>
  );
}
